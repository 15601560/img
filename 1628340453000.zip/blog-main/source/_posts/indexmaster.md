---
title: 你好啊，我的master
date: 2021-08-07 03:03:00
urlname: indexmaster
---
这是第一篇你的hexo文章

我的博客blog.imgblz.cn

QQ1608683211

来我的博客看怎么部署一样的博客吧！